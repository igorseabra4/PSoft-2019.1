package lab1.backend.other;

public class ServerTime {
	private String serverTime;

	public ServerTime(String serverTime) {
		this.serverTime = serverTime;
	}

	public String getTime() {
		return serverTime;
	}
}
